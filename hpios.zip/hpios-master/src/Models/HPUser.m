//
//  HPUser.m
//  HighPerformance
//
//  Created by Gaurav Vaish on 4/6/15.
//  Copyright (c) 2015 Gaurav Vaish. All rights reserved.
//

#import "HPUser.h"

@implementation HPUser

@end
