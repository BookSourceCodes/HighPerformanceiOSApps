//
//  HPAlbum.m
//  HighPerformance
//
//  Created by Gaurav Vaish on 8/17/14.
//  Copyright (c) 2014 Gaurav Vaish. All rights reserved.
//

#import "HPAlbum.h"
#import "HPPhoto.h"

@implementation HPAlbum

@synthesize name;
@synthesize creationTime;
@synthesize coverPhoto;
@synthesize photos;

@end
