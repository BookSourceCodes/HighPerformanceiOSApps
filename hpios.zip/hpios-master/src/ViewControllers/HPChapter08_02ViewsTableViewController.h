//
//  HPChapter08_02ViewsTableViewController.h
//  HighPerformance
//
//  Created by Gaurav Vaish on 2/15/15.
//  Copyright (c) 2015 Gaurav Vaish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HPChapter08_02ViewsTableViewController : UITableViewController

@end
