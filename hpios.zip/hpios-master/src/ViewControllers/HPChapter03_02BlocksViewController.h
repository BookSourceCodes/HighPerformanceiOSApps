//
//  HPChapter03_02BlocksViewController.h
//  HighPerformance
//
//  Created by Gaurav Vaish on 9/1/14.
//  Copyright (c) 2014 Gaurav Vaish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HPChapter03_02BlocksViewController : UIViewController

@property (nonatomic, strong) IBOutlet UILabel *resultLabel;
-(IBAction)onBlocksUsingLocalVariable:(id)sender;

@end
