//
//  HPDebugLogViewController.h
//  HighPerformance
//
//  Created by Gaurav Vaish on 9/6/14.
//  Copyright (c) 2014 Gaurav Vaish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HPDebugLogViewController : UIViewController

@property (nonatomic, strong) IBOutlet UITextView *logTextView;

@end
