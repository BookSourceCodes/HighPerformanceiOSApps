//
//  HPChapter08_02Views_10CustomViewsTableViewController.h
//  HighPerformance
//
//  Created by Gaurav Vaish on 2/16/15.
//  Copyright (c) 2015 Gaurav Vaish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HPChapter08_02Views_10CustomViewsTableViewController : UITableViewController

@property (nonatomic, assign) BOOL shouldUseDirect;

@end
