//
//  HPChapter07_VCLifecycleViewController.h
//  HighPerformance
//
//  Created by Gaurav Vaish on 2/11/15.
//  Copyright (c) 2015 Gaurav Vaish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HPChapter08_01VCLifecycleViewController : UIViewController

@property (nonatomic, copy) NSString *message;

-(IBAction)childViewControllerWasTapped:(id)sender;

@end
