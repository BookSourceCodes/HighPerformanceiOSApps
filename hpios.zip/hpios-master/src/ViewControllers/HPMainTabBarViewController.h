//
//  HPMainTabBarViewController.h
//  HighPerformance
//
//  Created by Gaurav Vaish on 8/22/14.
//  Copyright (c) 2014 Gaurav Vaish. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GADBannerView.h"
#import "GADBannerViewDelegate.h"

@interface HPMainTabBarViewController : UITabBarController <GADBannerViewDelegate>


@end
