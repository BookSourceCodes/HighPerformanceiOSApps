//
//  HPChapter17Tools_02AllocationsViewController.h
//  HighPerformance
//
//  Created by Gaurav Vaish on 6/6/15.
//  Copyright (c) 2015 Gaurav Vaish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HPChapter17Tools_02AllocationsViewController : UIViewController

@end
