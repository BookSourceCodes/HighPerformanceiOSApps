#!/bin/bash

echo NewRelic upload is disabled
#SCRIPT=`/usr/bin/find "${SRCROOT}" -name newrelic_postbuild.sh | head -n 1`
#/bin/sh "${SCRIPT}" "AA6a470f91b19445d67aceeb9813be9e080ce49823"
