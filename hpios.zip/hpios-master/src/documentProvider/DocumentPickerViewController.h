//
//  DocumentPickerViewController.h
//  documentProvider
//
//  Created by Gaurav Vaish on 3/22/15.
//  Copyright (c) 2015 Gaurav Vaish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DocumentPickerViewController : UIDocumentPickerExtensionViewController

@end
