//
//  HPConstants.h
//  HighPerformance
//
//  Created by Gaurav Vaish on 10/7/15.
//  Copyright (c) 2015 Gaurav Vaish. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const kHPKeyFlurry;
extern NSString *const kHPKeyCrashlytics;
extern NSString *const kHPKeyAmazonInsightsAppKey;
extern NSString *const kHPKeyAmazonInsightsPrivateKey;
extern NSString *const kHPKeyNewRelic;

