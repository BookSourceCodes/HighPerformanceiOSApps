//
//  HPConstants.m
//  HighPerformance
//
//  Created by Gaurav Vaish on 10/7/15.
//  Copyright (c) 2015 Gaurav Vaish. All rights reserved.
//

#import "HPConstants.h"

NSString *const kHPKeyFlurry = @"844GG5NC5WDJYHZWNXYT";
NSString *const kHPKeyCrashlytics = @"6b8ccdb8ba0cf4f64ed197effd3e48f1e3a07eb1";
NSString *const kHPKeyAmazonInsightsAppKey = @"c06cddbb1a30490489fb7aeb72ff4cde";
NSString *const kHPKeyAmazonInsightsPrivateKey = @"NiX7Pc9i88n4Q+1sXHcXwAPJwDKeVqHKDpC55uRO5e8=";
NSString *const kHPKeyNewRelic = @"AA6a470f91b19445d67aceeb9813be9e080ce49823";
