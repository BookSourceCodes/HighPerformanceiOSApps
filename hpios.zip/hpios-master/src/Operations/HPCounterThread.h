//
//  HPCounterOperation.h
//  HighPerformance
//
//  Created by Gaurav Vaish on 1/11/15.
//  Copyright (c) 2015 Gaurav Vaish. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HPCounterThread : NSObject

-(void)start;
-(void)stop;

@end
